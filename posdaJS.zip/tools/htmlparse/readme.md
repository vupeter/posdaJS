These scripts run on node.js if you need to use them please first get node.js from here: https://nodejs.org/

The linkanchorparse and booktableparse require cheeriojs module to run, to install dependancies run the following command inside parser folder:
npm install

To run parser scripts run command:
node linkanchorparse.js <directory> <output>
or
node linkupdate.js <iod directory> <linkanchorinput> <outputdirectory>